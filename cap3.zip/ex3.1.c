#include <stdio.h>
#include <stdlib.h>
 
int main(void){

for ( int i = 0; i <= 20 ; i++ ){ //i++ operador de incremento ,  i-- decrementa 1
    printf("%d ", i );
}



return 0;
}