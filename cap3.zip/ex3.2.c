#include <stdio.h>
#include <stdlib.h>
 
 int main (void){

for( int i = 0 ; i <= 50 ; i= i+2 ){
printf(" %d" , i );


}


    return 0;
 }